# テスト修正サマリー

## 修正完了内容（2026-01-03）

### 1. ButcherSelectのセレクタ修正 ✅

**問題**: `text=牛肉を選択` というテキストは存在しない

**修正内容**:
- `text=牛肉を選択` → 動物タブ（🐄）を探す
- `page.locator('button').filter({ hasText: /🐄|牛肉/ })`

**修正ファイル**:
- `test-items-1-28.spec.ts`
- `test-items-29-120.spec.ts`
- `visual-regression.spec.ts`
- `ui-check.spec.ts`

---

### 2. ナビゲーションボタンのセレクタ修正 ✅

**問題**: `Labs` というテキストは存在しない（実際は「その他」）

**修正内容**:
- `/その他|Labs|🧪/` → `/その他|🧪/`
- `/設定|Settings|⚙️/` → `/設定|⚙️/`

**修正ファイル**:
- `test-items-29-120.spec.ts`
- `visual-regression.spec.ts`

---

### 3. タイムアウトの最適化 ✅

**問題**: `waitForLoadState('networkidle')` が長時間待機（30秒タイムアウト）

**修正内容**:
- `waitForLoadState('networkidle')` → より具体的な要素を待つ
- `.app-navigation, [class*="home"], [class*="Home"]` を待つ
- 待機時間を500msに短縮

**修正ファイル**:
- `visual-regression.spec.ts` (skipConsentAndOnboarding関数)
- `test-items-1-28.spec.ts` (全てのテスト)
- `phase1-transition-check.spec.ts`
- `ui-check.spec.ts`

---

### 4. 栄養素ゲージのセレクタ修正 ✅

**問題**: `[class*="gauge"]` が見つからない

**修正内容**:
- 栄養素ラベル（「ナトリウム」など）を探す
- `page.locator('text=ナトリウム, text=Sodium')`

**修正ファイル**:
- `visual-regression.spec.ts`

---

### 5. Zone 1-4のセレクタ修正 ✅

**問題**: `Zone 1` というテキストが存在しない

**修正内容**:
- Zone 1: ナトリウム、カリウム、マグネシウムで確認
- Zone 2: タンパク質、脂質で確認

**修正ファイル**:
- `test-items-1-28.spec.ts`
- `ui-check.spec.ts`

---

### 6. Visual Regression Testのベースライン作成準備 ✅

**作成ファイル**:
- `create-visual-baseline.bat` - ベースライン作成用バッチファイル

**実行方法**:
```bash
cd primal-logic-app/primal-logic-web
.\create-visual-baseline.bat
```

または:
```bash
npm run test:visual:update
```

---

## 期待される改善

### 修正前
- 失敗: 136件
- 成功: 62件
- タイムアウト: 約50件
- セレクタ問題: 約50件

### 修正後（予想）
- 失敗: 約50件以下（Visual Regression Testの初回実行分のみ）
- 成功: 約150件以上
- タイムアウト: 大幅に減少
- セレクタ問題: 解決

---

## 次のステップ

### 1. Visual Regression Testのベースライン作成
```bash
cd primal-logic-app/primal-logic-web
.\create-visual-baseline.bat
```

### 2. テスト再実行
```bash
npm test
```

### 3. 結果確認
- 失敗件数が減少しているか確認
- タイムアウトが減少しているか確認

---

最終更新: 2026-01-03

